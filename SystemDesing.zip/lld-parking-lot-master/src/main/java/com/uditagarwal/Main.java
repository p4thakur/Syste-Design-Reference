package com.uditagarwal;

import com.uditagarwal.commands.CommandExecutor;
import com.uditagarwal.commands.CommandExecutorFactory;
import com.uditagarwal.exception.InvalidModeException;
import com.uditagarwal.mode.FileMode;
import com.uditagarwal.mode.InteractiveMode;
import com.uditagarwal.model.Command;
import com.uditagarwal.service.ParkingLotService;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
  public static void main(final String[] args) throws IOException {
    final OutputPrinter outputPrinter = new OutputPrinter();
    final ParkingLotService parkingLotService = new ParkingLotService();
    final CommandExecutorFactory commandExecutorFactory =
        new CommandExecutorFactory(parkingLotService);


   // BufferedReader reader = new BufferedReader( new InputStreamReader(System.in));
    outputPrinter.welcome();
    final BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    try{
      String line = reader.readLine();
      while(line !=null ){
        Command command = new Command(line);
//        CommandExcuterClass commandExcuterClass =
//                commandExecutorFactory.getCommandExecuter(command);
        final CommandExecutor commandExecutor =
                commandExecutorFactory.getCommandExecutor(command);

        commandExecutor.execute(command);
      }
    } catch (Exception ex) {

    }


//
//    if (isInteractiveMode(args)) {
//      new InteractiveMode(commandExecutorFactory, outputPrinter).process();
//    } else if (isFileInputMode(args)) {
//      new FileMode(commandExecutorFactory, outputPrinter, args[0]).process();
//    } else {
//      throw new InvalidModeException();
//    }
//  }
//
//  /**
//   * Checks whether the program is running using file input mode.
//   *
//   * @param args Command line arguments.
//   * @return Boolean indicating whether in file input mode.
//   */
//  private static boolean isFileInputMode(final String[] args) {
//    return args.length == 1;
//  }
//
//  /**
//   * Checks whether the program is running using interactive shell mode.
//   *
//   * @param args Command line arguments.
//   * @return Boolean indicating whether in interactive shell mode.
//   */
//  private static boolean isInteractiveMode(final String[] args) {
//    return args.length == 0;
  }
}
