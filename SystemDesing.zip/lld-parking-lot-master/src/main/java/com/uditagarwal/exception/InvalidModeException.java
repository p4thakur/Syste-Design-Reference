package com.uditagarwal.exception;

/**
 * Exception given when the mode cannot be decided for the parking lot program.
 */
public class InvalidModeException extends RuntimeException {

}
