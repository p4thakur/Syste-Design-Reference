package com.uditagarwal.exception;

/**
 * Exception given when the command given is invalid or the command params are invalid.
 */
public class InvalidCommandException extends RuntimeException {

}
