package com.prateek.parkinglot.Model;

public class Slot {
    private Integer sloteNumber;
    private Car parkedCar;


//   note that when I creat slot there is no car there. I
//    public Slot(Integer sloteNumber, Car parkedcar) {
//        this.sloteNumber = sloteNumber;
//        this.parkedcar = parkedcar;
//    }
  public Slot(Integer sloteNumber) {
    this.sloteNumber = sloteNumber;
}

    public void setSloteNumber(Integer sloteNumber) {
        this.sloteNumber = sloteNumber;
    }

    public Car getParkedcar() {
        return parkedCar;
    }

    //now Slot will be filled when I asign  the car
    public void setParkedcar(Car parkedCar) {
        this.parkedCar = parkedCar;
    }

    public void unassignedCar(){
        this.parkedCar =null;
    }

    //check if this slot  is avaialble
    public boolean isSlotAvaialabl(){
      return  this.parkedCar == null;
    }

    public Integer getSloteNumber() {
        return sloteNumber;
    }


}
