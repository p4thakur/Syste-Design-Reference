package com.prateek.parkinglot.Model;

import java.util.HashMap;
import java.util.Map;

public class ParkingLot {
    int MAX_CAPACITY=5000;
    int capacity;
    //list of slot that is already asccoited to parking lot
    //I will also need way to kepp track of slot number . so let use map
    Map<Integer , Slot> slots;

    public ParkingLot(int capacity) {
        this.capacity = capacity;
        this.slots = new HashMap<>();
    }


    public Slot AssignSlot(Car car, Integer slotNum){
        //check that slot number lies betweenn cappacity and max capacity
       Slot slot = new Slot(slotNum);
        slot.setParkedcar(car);
       if(!slots.containsKey(slotNum)){
           slots.put(slotNum, slot);
       }
       //else throw excpetion that slot is already full
        return slot;
    }

    public void removeSlot(Integer sloteNumber) {
        //find Slot form the map
        if(slots.containsKey(sloteNumber)) {
            //remove it from map and unmaked the car
            Slot slot = slots.get(sloteNumber);
            slot.unassignedCar();//sees Car object to null
        }
    }


}
