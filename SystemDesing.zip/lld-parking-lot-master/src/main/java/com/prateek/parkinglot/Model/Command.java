package com.prateek.parkinglot.Model;

import java.util.Arrays;
import java.util.List;

public class Command {

    String  command;
    List<String> params;

    public List<String> getParams() {
        return params;
    }

    public String getCommand() {
        return command;
    }

    public Command(String inputline) {
   //firsting Sring willbe comand rest will be list of param
     //if(inputline == null) { //throwExcpetion}
    String[]  str = inputline.split(" ");
    this.command = str[0];
     List<String>  params =   Arrays.asList(str);
        params.remove(0);//since first one was command
        this.params = params;
    }

}
