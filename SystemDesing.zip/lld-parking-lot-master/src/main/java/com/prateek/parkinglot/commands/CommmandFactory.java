package com.prateek.parkinglot.commands;

import com.prateek.parkinglot.Model.Command;
import com.prateek.parkinglot.Service.ParkingLotService;

import java.util.Map;

public class CommmandFactory {
    Map<String, CommandExcuterClass> commandExcuterClassMap;

    public CommmandFactory(ParkingLotService parkingLotService){

        commandExcuterClassMap.put(CommandCreateParkingLot.COMMAND ,
                new CommandCreateParkingLot(parkingLotService));
        commandExcuterClassMap.put(CommandForPark.COMMAND ,
                new CommandForPark(parkingLotService));
        commandExcuterClassMap.put(CommandForRegistrationNumber.COMMAND ,
                new CommandForRegistrationNumber(parkingLotService));
        commandExcuterClassMap.put(CommandForSlotWithRegistrationNumber.COMMAND ,
                new CommandForSlotWithRegistrationNumber(parkingLotService));
    }
    //fill up the map at time of creating this MAP

    public CommandExcuterClass getCommandExecuter(Command command){

         if(commandExcuterClassMap.containsKey(command.getCommand())){
             return commandExcuterClassMap.get(command.getCommand());
         }
         //throw Exption here
         return null;
    }
}
