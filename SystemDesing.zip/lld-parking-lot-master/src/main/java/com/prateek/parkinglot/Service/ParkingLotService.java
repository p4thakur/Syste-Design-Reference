package com.prateek.parkinglot.Service;

import com.prateek.parkinglot.Model.Car;
import com.prateek.parkinglot.Model.ParkingLot;

public class ParkingLotService {

    ParkingLot parkingLot;
    //add parkingLot Strategy
    ParkingLotStrategy parkingLotStrategy;

    public ParkingLotService(ParkingLot parkingLot, ParkingLotStrategy parkingLotStrategy) {
        this.parkingLot = parkingLot;
        this.parkingLotStrategy = parkingLotStrategy;
    }


    public void assignSpot(Car car) {
        //I will need to allocate the slot to this car.
        //slote number will be fetch based on my algp

    }
}
