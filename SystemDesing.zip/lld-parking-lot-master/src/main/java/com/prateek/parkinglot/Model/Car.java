package com.prateek.parkinglot.Model;

public class Car {
    String registrationNumber;
    String color;
}
