package com.prateek.parkinglot;

import com.prateek.parkinglot.Model.Command;
import com.prateek.parkinglot.Service.*;
import com.prateek.parkinglot.commands.CommandExcuterClass;
import com.prateek.parkinglot.commands.CommmandFactory;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class ParkingLotMainApplication {
//
//    public static  void main(String[]  args){
//
//        ParkingLotService parkingLotService = new ParkingLotService();
//        ParkingLotStrategy parkingLotStrategy ;
//
//        CommmandFactory  commmandFactory = new CommmandFactory(parkingLotService);
//        //now I will need to call my serice cal. its like calling my APIs
//        //we will be getting inpu from file or serice. whatver the case we will be processing
//        // the ddifferent dpend upon deifferent comman.
//        //let creat Commoand Excuter call for  the same. which will be calling out services.
//
//        //Now read the input file or console
//       ;
//        BufferedReader reader = new BufferedReader( new InputStreamReader(System.in));
//        try{
//            String line = reader.readLine();
//            while(line !=null ){
//            Command command = new Command(line);
//            CommandExcuterClass commandExcuterClass =
//                    commmandFactory.getCommandExecuter(command);
//            commandExcuterClass.executeCommand(command);
//            }
//        } catch (Exception ex) {
//
//        }
//
//
//    }
}
