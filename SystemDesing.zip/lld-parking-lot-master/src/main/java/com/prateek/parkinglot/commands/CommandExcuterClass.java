package com.prateek.parkinglot.commands;

import com.prateek.parkinglot.Model.Command;

public abstract class CommandExcuterClass {

   protected void  processCommand(Command command) {
       //find out the command and parameter

   };

   public abstract void   executeCommand(Command command);
}
