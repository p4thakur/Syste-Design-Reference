package com.prateek.parkinglot.Service;


public interface ParkingLotStrategy {

    public void addingParkingSpotOrder(int parkingSpotNumber);

    public void removeparkingSpot();


    Integer nextSpot();
}
