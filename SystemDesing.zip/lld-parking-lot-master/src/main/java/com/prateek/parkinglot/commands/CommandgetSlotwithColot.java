package com.prateek.parkinglot.commands;

import com.prateek.parkinglot.Model.Command;
import com.prateek.parkinglot.Service.ParkingLotService;

public class CommandgetSlotwithColot extends CommandExcuterClass {

    final static String COMMAND= "park";
    ParkingLotService parkingLotService;
    public  CommandgetSlotwithColot(ParkingLotService parkingLotService){
        this.parkingLotService = parkingLotService;
    }

    @Override
    public void executeCommand(Command command) {

    }
}
