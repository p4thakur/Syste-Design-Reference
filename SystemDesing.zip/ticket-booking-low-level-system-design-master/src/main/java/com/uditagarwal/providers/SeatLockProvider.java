package com.uditagarwal.providers;

import com.uditagarwal.model.Seat;
import com.uditagarwal.model.Show;

import java.util.List;
//i can use redis, or inmemory or any other way to do the same .I am following openclose principle here
public interface SeatLockProvider {

    void lockSeats(Show show, List<Seat> seat, String user);
    void unlockSeats(Show show, List<Seat> seat, String user);
    boolean validateLock(Show show, Seat seat, String user);

    List<Seat> getLockedSeats(Show show);
}
