package com.uditagarwal.model;

import lombok.Getter;
import lombok.NonNull;

import java.util.ArrayList;
import java.util.List;

@Getter //I am using the getter not setter since I wll probabily never going to set its parameter
//again .I may change its behavior(like in addScrenn method). This is done to avoid mutability.
//don't sexpose setter if you know no one shpuld update it. it's good design. noboday can't update it by mistake
public class Theatre {

    private final String id;
    private final String name;
    private final List<Screen> screens;
    //Other theatre metadata.(location and other stuff). don't try to add all variable. just use minimum
    //proprty. Focus on the minimal use cases and working solution first

    public Theatre(@NonNull final String id, @NonNull final String name) {
        this.id = id;
        this.name = name;
        this.screens = new ArrayList<>();
    }

    public void addScreen(@NonNull final  Screen screen) {
        screens.add(screen);
    }
}
