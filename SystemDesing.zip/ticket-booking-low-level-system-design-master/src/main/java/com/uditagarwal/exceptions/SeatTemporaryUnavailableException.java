package com.uditagarwal.exceptions;

public class SeatTemporaryUnavailableException extends RuntimeException {
}
