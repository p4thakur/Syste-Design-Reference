package com.uditagarwal.exceptions;

public class InvalidStateException extends RuntimeException {
}
