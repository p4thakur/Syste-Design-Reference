package com.uditagarwal.exceptions;

public class ScreenAlreadyOccupiedException extends RuntimeException {
}
