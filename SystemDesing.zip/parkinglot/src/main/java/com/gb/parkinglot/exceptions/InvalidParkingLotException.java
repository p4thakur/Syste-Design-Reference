package com.gb.parkinglot.exceptions;

public class InvalidParkingLotException extends Exception {
    public InvalidParkingLotException(String message) {
        super(message);
    }
}
