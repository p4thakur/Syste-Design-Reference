package com.gb.parkinglot.exceptions;

public class InvlaidParkingFloorException extends Exception {
    public InvlaidParkingFloorException(String message) {
        super(message);
    }
}
