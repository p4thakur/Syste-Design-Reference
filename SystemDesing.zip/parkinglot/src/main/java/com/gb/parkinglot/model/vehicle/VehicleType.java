package com.gb.parkinglot.model.vehicle;

public enum VehicleType {
    CAR,
    TRUCK,
    ELECTRIC,
    VAN,
    MOTORBIKE,
    EBIKE
}
