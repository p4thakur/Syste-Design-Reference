package com.gb.parkinglot.model.parking;

public class MotorBikeParkingSpot extends ParkingSpot {
    public MotorBikeParkingSpot(String id) {
        super(id, ParkingSpotType.MOTORBIKE);
    }
}
