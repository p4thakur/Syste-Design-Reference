package com.gb.parkinglot.model.parking;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class PaymentPortal {
    private String id;

    public void scanTicket(ParkingTicket parkingTicket) {

    }

    public void makePayment(ParkingTicket parkingTicket) {

    }
}
