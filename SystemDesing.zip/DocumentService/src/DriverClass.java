import ENUMs.DocumentAccess;
import ENUMs.DocumentType;
import Model.Account;
import Model.Document;
import Model.Owner;
import Model.Person;

import java.util.Map;
import java.util.UUID;

public class DriverClass {

    public static void main(String[]  args){

        //create User
       Account account =
               new Account(UUID.randomUUID().toString(), "2121331", "paswword");
        Owner owner = new Owner("prateek", "abc@gmail.com", account);

        //I can add docmeunt Service here that will intercat with moded

        owner.createDocument(DocumentType.WORD,"Title for Doc1");

        Map<String, Document>  documentList= owner.getDocumentIdMap();
        for (Map.Entry<String,Document> entry : documentList.entrySet()){
            System.out.println("Key = " + entry.getKey() +
                    ", Access = " + entry.getValue().getAccess() +
                    ", Title = " + entry.getValue().getTitle());
            System.out.println("Updatin access for the given Document");
            entry.getValue().setAccess(DocumentAccess.READ);
            System.out.println("Key = " + entry.getKey() +
                    ", Access = " + entry.getValue().getAccess() +
                    ", Title = " + entry.getValue().getTitle());
            System.out.println("checking  Permission for the given Document");
            entry.getValue().setAccess(DocumentAccess.READ);
            System.out.println("Key = " + entry.getKey() +
                    ", Permission = " + entry.getValue().getPermission() +
                    ", Title = " + entry.getValue().getTitle());
        }




    }
}
