package ENUMs;

public enum DocumentType {
    WORD, EXCEL, OTHER
}
