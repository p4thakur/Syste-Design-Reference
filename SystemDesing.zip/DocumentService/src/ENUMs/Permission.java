package ENUMs;

public enum Permission {

    PRIVATE, PUBLIC, GROUP
}
