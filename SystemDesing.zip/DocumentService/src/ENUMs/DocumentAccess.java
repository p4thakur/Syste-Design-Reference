package ENUMs;

public enum DocumentAccess {
   READ,EDIT, DELETE,COPY, NO_ACESSS
}
