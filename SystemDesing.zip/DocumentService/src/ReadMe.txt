All documents are private when created.
Owners of
 documents can {grant} {read OR edit} access to other users
Grants  can be made at global level as well. For example,
 if read access is granted globally, then every user should have access to read that document.
Only the owner can delete a document
Username will be just a string. Every action like create/read/edit/delete must be associated with a username.
Have different tiers. Hot tier should be served from memory. Cold tier should be served from the disk. service should be able to bring the globally frequently accessed documents into the hot tier.
