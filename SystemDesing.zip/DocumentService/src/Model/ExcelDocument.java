package Model;

import ENUMs.Permission;

import javax.print.Doc;

public class ExcelDocument  extends Document {



    public ExcelDocument(String id, String title) {
        super(id, title);
    }
}
