package Model;

import Model.Strategy.StrategyToAddDocument;

import javax.print.Doc;
import java.util.Map;

public class HotTier extends  Tier{
    private int docLimit;
    private static int currentLimit;
    private StrategyToAddDocument  strategyToAddDocument;
    Map<String, Document> docIdToDocument;

    public HotTier(int docLimit, StrategyToAddDocument strategyToAddDocument){
        super();
        this.docLimit= docLimit;
        this.strategyToAddDocument = strategyToAddDocument;
        currentLimit++;
    };
    @Override
    public void addDocument(Document document) {
    // add documet based on sertain strategy
        Boolean isCacheFull = currentLimit >  docLimit? true :false;
    this.strategyToAddDocument.addDocument(document, isCacheFull);
    }

    @Override
    public void removeDocument(String docId) {

    }

}
