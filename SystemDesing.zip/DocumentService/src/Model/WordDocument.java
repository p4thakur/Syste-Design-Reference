package Model;

import ENUMs.Permission;

public class WordDocument extends Document{

    public WordDocument(String id, String title) {
        super(id, title);
    }
}
