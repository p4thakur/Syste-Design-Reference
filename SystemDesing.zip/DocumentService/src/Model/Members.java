package Model;

public class Members extends  Person{

    public Members(String name, String emailId, Account account) {
        super(name, emailId, account);
    }


    public void createDocument(){

    }

    public void editDocument(){

    }
}
