package Model;

public class Account {

    private String id;
    private String phoneNumb;
    private String password;

    public Account(String id, String phoneNumb, String password) {
        this.id = id;
        this.phoneNumb = phoneNumb;
        this.password = password;
    }

    public void resetPaswwor(){

    }
}
