package Model;

import ENUMs.DocumentType;

import java.util.HashMap;
import java.util.Map;

public  class DocumentTypeFactory {

    Map<DocumentType, DocumentExcuter> typeToDcoument;



    public DocumentTypeFactory(){
        typeToDcoument= new HashMap<>();
        typeToDcoument.put(DocumentType.EXCEL,new ExcelFactoryImp());
        typeToDcoument.put(DocumentType.WORD,new WordExcelfactory());
    }



     public DocumentExcuter  getExcutedCommad(DocumentType documentType){

        return  typeToDcoument.get(documentType);
     }
    //public abstract   Document createDocuemnt(String id, String title);

}
