package Model;

import ENUMs.DocumentType;
import ENUMs.Permission;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Person {

    protected Permission permission;
    protected  Map<String,Document> documentIdMap;
    private String name;
    private String emailId;
    private Account account;

    public Person(String name, String emailId, Account account) {
        this.name = name;
        this.emailId = emailId;
        this.account = account;
        this.documentIdMap = new HashMap<>() ;
        this.permission = Permission.PRIVATE;
    }


    public Map<String, Document> getDocumentIdMap() {
        return documentIdMap;
    }

    public void addDocument(Document document){
        documentIdMap.put(document.getId(), document);
    }


//other metdata
}
