package Model;

import ENUMs.DocumentAccess;
import ENUMs.Permission;

import java.util.Date;

public class Document {

    private String id;
    private String title;
    private String  descrition;
    private Date  createdOn;
    private Date updatedOn;
    private Permission permission;
    private DocumentAccess access;
    private Person owner;

    public Document(String id, String title) {
        this.id = id;
        this.title = title;
        this.permission = Permission.PRIVATE;
        this.createdOn= new Date();
        this.updatedOn = new Date();

    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescrition() {
        return descrition;
    }

    public void setDescrition(String descrition) {
        this.descrition = descrition;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public Date getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(Date updatedOn) {
        this.updatedOn = updatedOn;
    }

    public Permission getPermission() {
        return permission;
    }

    public void setPermission(Permission permission) {
        this.permission = permission;
    }

    public DocumentAccess getAccess() {
        return access;
    }

    public void setAccess(DocumentAccess access) {
        this.access = access;
    }

    public Person getOwner() {
        return owner;
    }

    public void setOwner(Person owner) {
        this.owner = owner;
    }
}
