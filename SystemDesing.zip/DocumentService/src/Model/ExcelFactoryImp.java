package Model;

public class ExcelFactoryImp extends   DocumentExcuter{

    public  Document createDocuemnt(String id, String title){
        return new WordDocument(id, title);
    }
}
