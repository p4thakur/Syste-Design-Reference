package Model;

import Model.Strategy.StrategyToAddDocument;

import javax.print.Doc;

public abstract class Tier {
    private int MAX_SIZE = 100000;

    public abstract void addDocument(Document document);
    public abstract void removeDocument(String docId);
}
