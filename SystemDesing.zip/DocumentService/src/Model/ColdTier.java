package Model;

public class ColdTier extends  Tier{


    @Override
    public void addDocument(Document document) {

    }

    @Override
    public void removeDocument(String docId) {

    }
}
