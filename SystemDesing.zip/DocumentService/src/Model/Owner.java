package Model;

import ENUMs.DocumentAccess;
import ENUMs.DocumentType;
import ENUMs.Permission;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class Owner extends  Person{


    public Owner(String name, String emailId, Account account) {
        super(name, emailId, account);
       this.permission=Permission.PRIVATE;
    }

    public void createDocument(DocumentType document, String title){
      //create Docuemt with current user as owner. I can use injection here
        DocumentTypeFactory documentTypeFactory= new DocumentTypeFactory();
        DocumentExcuter documentExcuter=  documentTypeFactory.getExcutedCommad(document);
       Document createdDocument= documentExcuter.createDocuemnt(UUID.randomUUID().toString(),title);
        createdDocument.setAccess(DocumentAccess.NO_ACESSS);
        createdDocument.setPermission(Permission.PRIVATE);
        createdDocument.setCreatedOn(new Date());
        createdDocument.setUpdatedOn(new Date());
        createdDocument.setOwner(this);
        this.addDocument(createdDocument);

    }

     public void editDocument(String documentId,String updatedquery){
        Document document = documentIdMap.get(documentId);

        //for now lests udate just deccripto
         document.setDescrition(updatedquery);
         document.setUpdatedOn(new Date());
     }

     public  void deleteDocument(String documentId){
      //remove the document
         Map<String , Document>  map=this.getDocumentIdMap();
          if(map.containsKey(documentId)){
              map.remove(documentId);
          }
     }



     public void changeDocumentAccess(Document document){

     }

    public void changePermission(Document document){

    }


}
