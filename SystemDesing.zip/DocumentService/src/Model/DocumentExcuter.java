package Model;

public abstract  class DocumentExcuter {

    public abstract   Document createDocuemnt(String id, String title);

}
