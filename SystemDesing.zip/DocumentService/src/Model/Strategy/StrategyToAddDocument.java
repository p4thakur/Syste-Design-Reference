package Model.Strategy;

import Model.Document;

public interface StrategyToAddDocument {

    public void addDocument(Document document,boolean isCachFull);
    public void removeDocument(Document document);

}
