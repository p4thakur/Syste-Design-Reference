package Model.Strategy;

import Model.Document;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class FrequentlyUsedStrategy implements  StrategyToAddDocument{
    Map<String, Integer>  DocIdToFrequencMap ;//mapping from freq to coc Id
    Map<String,Document> hotshardDocument;// list of Document present in hot shard
    Map<String,Document> coldshardDocument;

    public FrequentlyUsedStrategy (){
        DocIdToFrequencMap = new TreeMap<>();
        hotshardDocument = new HashMap<>();
        coldshardDocument = new HashMap<>();
    }
    @Override
    public void addDocument(Document document, boolean isCachFull) {
        //if I can still add doc to hot shard
        if(!isCachFull) {
            //update the frequncy of doc
            DocIdToFrequencMap.put(document.getId(), DocIdToFrequencMap.get(document.getId() + 1));
            //add into shard if not present
            if (!DocIdToFrequencMap.containsKey(document.getId())) {
                hotshardDocument.put(document.getId(), document);

            }

        } else {
            //if my cache is full remove the lest frequnct used data from map and add that to cold Shard
            hotshardDocument.remove(document.getId());
            //put this in cold shard
            coldshardDocument.put(document.getId(), document);
        }
    }

    @Override
    public void removeDocument(Document document) {

    }
}
