package com.workattech.splitwise.models.expense;

public enum ExpenseType {
    EQUAL,
    EXACT,
    PERCENT
}
