package com.workattech.splitwise.models.split;

import com.workattech.splitwise.models.User;

public class EqualSplit extends Split {

    public EqualSplit(User user) {
        super(user);
    }
}
