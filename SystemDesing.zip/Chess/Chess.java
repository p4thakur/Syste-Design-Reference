public class Chess {

	ChessBoard chessBoard;
	Player[] player;
	Player currentPlayer;
	List<Move> movesList;
	GameStatus gameStatus;

	public boolean playerMove(CellPosition fromPosition, CellPositionb toPosition, Piece piece); 
	public boolean endGame();
	private void changeTurn();//this is private as it will becalled from player moe api

}

public class Player {

	Account account;
	Color color;
	Time timeLeft;

}
 
public class Time {

	int mins;
	int secs;

}

public enum Color {

	BLACK, WHITE;
	
}

public class Account {

	String username;
	String password;

	String name;
	String email;
	String phone;
}

public enum GameStatus {

	ACTIVE, PAUSED, FORTFEIGHT, BLACK_WIN, WHITE_WIN;
}

public class ChessBoard {

	List<List<Cell>>> board;//this make sure I can have different dimesion of chess

	public void resetBoard();
	public void updateBoard(Move move);//playmove from chess enitity call this API
}

public class Cell {

	Color color;
	Piece piece;//may or may not have piece
	CellPosition position;
}

public class CellPosition {
    //board row is in chactert and row in number 
	Char ch;
	int i;
}

public class Move {

	Player turn;
	Piece piece;
	Piece killedPiece;//if any piece has been killd
	CellPosition startPosition;
	CellPosition endPosition;

}

public abstract class Piece {

	Color color;

	public boolean move(CellPosition fromPosition, CellPositionb toPosition);
	public List<CellPosition> possibleMoves(CellPosition fromPosition);
	public boolean validate(CellPosition fromPosition, CellPositionb toPosition);
}

public class Knight extends Piece {

	public boolean move(CellPosition fromPosition, CellPositionb toPosition);
	public List<CellPosition> possibleMoves(CellPosition fromPosition);
	public boolean validate(CellPosition fromPosition, CellPositionb toPosition);

}

public class Bishop extends Piece {
	
	public boolean move(CellPosition fromPosition, CellPositionb toPosition);
	public List<CellPosition> possibleMoves(CellPosition fromPosition);
	public boolean validate(CellPosition fromPosition, CellPositionb toPosition);

}

public class rook extends Piece {
	
	public boolean move(CellPosition fromPosition, CellPositionb toPosition);
	public List<CellPosition> possibleMoves(CellPosition fromPosition);
	public boolean validate(CellPosition fromPosition, CellPositionb toPosition);

}

public class King extends Piece {
	
	public boolean move(CellPosition fromPosition, CellPositionb toPosition);
	public List<CellPosition> possibleMoves(CellPosition fromPosition);
	public boolean validate(CellPosition fromPosition, CellPositionb toPosition);

}

public class Queen extends Piece {
	
	public boolean move(CellPosition fromPosition, CellPositionb toPosition);
	public List<CellPosition> possibleMoves(CellPosition fromPosition);
	public boolean validate(CellPosition fromPosition, CellPositionb toPosition);

}

public class Pawn extends Piece {
	
	public boolean move(CellPosition fromPosition, CellPositionb toPosition);
	public List<CellPosition> possibleMoves(CellPosition fromPosition);
	public boolean validate(CellPosition fromPosition, CellPositionb toPosition);

}